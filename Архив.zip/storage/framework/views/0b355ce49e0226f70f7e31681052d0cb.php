<?php $__env->startSection('head'); ?>
<title>Посты | ActQA</title>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
<h1>Список постов</h1>
    <div class="">
        <?php if(session()->has('status')): ?>

            <div class="flex justify-center items-center">
                <p class="ml-3 text-sm font-bold text-green-600"><?php echo e(session()->get('status')); ?></p>
            </div>
        <?php endif; ?>

        <div class="mt-1 mb-4">
             <a class="btn" href="<?php echo e(route('posts.create')); ?>">+ Добавить пост</a>
        </div>
        <div class="table-overfolow">
            <table class="table-list">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Заголовок</th>
                        <th>Черновик</th>
                        <th>Дата публикации</th>
                        <th>Обновленно</th>
                        <th>Дата создания</th>
                        <th></th>
            
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="post-row">
                        <td><?php echo e($post->id); ?></td>
                        <td>
                            <a  class="post-row__link" href="<?php echo e(route('posts.show', $post->id)); ?>"><?php echo e($post->title); ?></a></td>
                        <td>
                            <?php if($post->draft  == 1): ?>
                            Да
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($post->delay); ?></td>
                        <td><?php echo e($post->updated_at); ?></td>
                        <td><?php echo e($post->created_at); ?></td>
                        <td>
                            
                            <div class="actions-btns-row">
                                <a  class="btn-edit" href="<?php echo e(route('posts.edit', $post->id)); ?>">
                                    <svg  viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m18 10-4-4m4 4 3-3-4-4-3 3m4 4-1 1m-3-5-6 6v4h4l2.5-2.5m5.5.5v6h-8M10 4H4v16h3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
</a>
                    
                                <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST"
                                    onsubmit="return confirm('<?php echo e(trans('Are You Sure ? ')); ?>');"
                                    style="display: inline-block;">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <button type="submit" class="btn-delete"
                                        value="Delete">
                                        <svg   viewBox="0 -0.5 21 21" xmlns="http://www.w3.org/2000/svg"><path d="M7.35 16h2.1V8h-2.1v8Zm4.2 0h2.1V8h-2.1v8Zm-6.3 2h10.5V6H5.25v12Zm2.1-14h6.3V2h-6.3v2Zm8.4 0V0H5.25v4H0v2h3.15v14h14.7V6H21V4h-5.25Z" fill="currentColor" fill-rule="evenodd"/></svg>
                                    </button>
                                </form>
                            </div>
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td colspan="7"  ><b>Постов нет</b></td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($posts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sergejabramov/Desktop/domains/geek/resources/views/posts/index.blade.php ENDPATH**/ ?>