   <?php $__env->startSection('head'); ?>
<title>О нас | ActQA</title>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

    <div class="page-about"><h1>О нас</h1>
<p>Мы команда Актион, поставляем профессиональную информацию и знания миллионам специалистов — бухгалтерам, кадровикам, финансистам, юристам, медикам, учителям и управленцам. Кроме этого мы успешно обучаем новым профессиям, подробнее про нас <a href="https://action.group/about/">https://action.group/about/</a></p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sergejabramov/Desktop/domains/geek/resources/views/about.blade.php ENDPATH**/ ?>