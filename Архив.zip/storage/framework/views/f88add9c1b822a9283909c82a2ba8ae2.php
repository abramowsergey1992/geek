<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

            
        <?php echo $__env->yieldContent('head'); ?>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <script src="https://cdn.ckeditor.com/ckeditor5/41.0.0/classic/ckeditor.js"></script>
<!-- 
        <script>
        tinymce.init({
            selector: 'textarea.editor', // Replace this CSS selector to match the placeholder element for TinyMCE
            plugins: 'powerpaste advcode table lists checklist',
            toolbar: 'undo redo | blocks| bold italic | bullist numlist checklist | code | table'
        });
        </script> -->

        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.scss', 'resources/js/app.js']); ?>
    </head>
 
<body>

        <div class="layout">
            <header class="header">
                <div class="inner">
                    <div class="header__row">
         
                      <ul class="main-menu">
                            <li>
                                <a href="/"  class="
                                <?php if(Request::path() === '/'): ?>
_active
 <?php endif; ?> ">Главная</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('about')); ?>"  class="
                                <?php if(Request::path() === 'about'): ?>
_active
 <?php endif; ?> " >О нас</a>
                            </li>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                            <li>
                                <a href="<?php echo e(route('posts.index')); ?>"  class="
                                <?php if(Request::path() === 'posts'): ?>
_active
 <?php endif; ?> "">Посты</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('students.index')); ?>"  class="
                                <?php if(Request::path() === 'students'): ?>
_active
 <?php endif; ?> ">Пользователи</a>
                            </li>
                    <?php endif; ?>
                            <li>
                                 <?php if(Route::has('login')): ?>
                        
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('students.show',Auth::user()->id)); ?>" class="toolbar__link 
                                    <?php if(Request::path() === 'students/'.Auth::user()->id): ?>
                                        _active
                                    <?php endif; ?>">Профиль</a>
                                    <ul>
                                        <li> 
                                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <a href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();
                                                                    this.closest('form').submit();">Выйти</a>

                                            </form>
                                        </li>
                                    </ul> 
                                     <?php endif; ?>
                                <?php endif; ?>
                                <?php if(!Auth::check()): ?>
                                    <a href="<?php echo e(route('login')); ?>" class="toolbar__link">Войти</a>
                                    <!-- <span class="divider">/</span>
                                    <?php if(Route::has('register')): ?>
                                        <a href="<?php echo e(route('register')); ?>" class="toolbar__link">Register</a>
                                    <?php endif; ?> -->
                            
                            
                                 <?php endif; ?>
                            </li>
                        </ul>
                     </div>
                </div>
                    <!-- <div class="toolbar">
                        <?php if(Route::has('login')): ?>
                        
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(url('/dashboard')); ?>" class="toolbar__link">My profile</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>" class="toolbar__link">Log in</a>
                                    <span class="divider">/</span>
                                    <?php if(Route::has('register')): ?>
                                        <a href="<?php echo e(route('register')); ?>" class="toolbar__link">Register</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            
                        <?php endif; ?>
                    </div> -->
                  
               
            </header>
            <main>
                <div class="inner">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>
            <footer class="footer">
                <div class="inner">
                    <div class="footer__copy">
                    Все права защещены ⓒ <?php echo e(now()->year); ?>, Action Group
                    </div>
                </div>
            </footer>
        </div>        <script>
    //         if( document.querySelector( 'textarea.editor' )){
    // ClassicEditor
    //     .create( document.querySelector( 'textarea.editor' ) )
    //     .catch( error => {
    //         console.error( error );
    //     } );}
</script>
</body>
 
</html>
<?php /**PATH /Users/sergejabramov/Desktop/domains/geek/resources/views/layouts/layout.blade.php ENDPATH**/ ?>