 

<?php $__env->startSection('content'); ?>
<h1>Edit Post</h1>


        <form method="POST" enctype="multipart/form-data"  action="<?php echo e(route('posts.update',$post->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
            <label class="form-item">
                <span class="form-item__title">Title</span>
                <input name="title" placeholder=""  value="<?php echo e(old('title', $post->title)); ?>" type="text" >
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="form-item__error"><?php echo e($message); ?></span> 
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="form-item">
                <span class="form-item__title">Description</span>
                <div class="textarea" ><textarea maxlength="100"   name="description" placeholder=""  value="" ><?php echo e(old('description',$post->description)); ?></textarea>
                 <div class="textarea__counter"></div>
            </div> <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="form-item__error"><?php echo e($message); ?></span> 
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="form-item">
                <span class="form-item__title">Content</span>
                <div class="textarea" > <textarea class="editor" maxlength="1000"  name="content" placeholder=""  value="<?php echo e(old('content')); ?>" ><?php echo e(old('content',$post->content)); ?></textarea>
                 <div class="textarea__counter"></div>
            </div> <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="form-item__error"><?php echo e($message); ?></span> 
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <div class="form-item">
                <span class="form-item__title">Photo</span>
                <div class="input-file-row">
                    <label class="input-file">
                        <input type="file" name="photo"   accept="image/*">		
                        <span>Select file</span>
                    </label>
                    <div class="input-file-list">
                        <div class="input-file-list-item">
                            <img class="input-file-list-img" src="<?php echo e(asset('storage/images/'.$post->photo)); ?>">
                            <span class="input-file-list-name"><?php echo e($post->photo); ?></span>
                            <a href="#" class="input-file-list-remove"></a></div>
                    </div>
                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="form-item__error"><?php echo e($message); ?></span> 
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="form-item">
                <span class="form-item__title">Delay</span>
                <input class="datepicker" name="delay" placeholder=""  value="<?php echo e(\Carbon\Carbon::parse($post->delay)->format('d.m.Y H:i')  ?? old('delay')); ?> " type="text" >
                <?php $__errorArgs = ['delay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="form-item__error"><?php echo e($message); ?></span> 
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="form-item">
                <span class="toogle">
                <span class="form-item__title">Is Draft </span> <span class="toogle__indicator">
                <input     
                <?php if($post->draft == 0): ?>
                checked
                <?php endif; ?>
                 type="checkbox" value="0" name='draft'></span>
                </span>
                <?php $__errorArgs = ['draft'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="form-item__error"><?php echo e($message); ?></span> 
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
     
            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>
                Submit
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>

        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sergejabramov/Desktop/domains/geek/resources/views/posts/edit.blade.php ENDPATH**/ ?>