 <?php $__env->startSection('head'); ?>
<title>Лента постов | ActQA</title>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
<h1>Лента постов</h1>
    <div class="">
        <?php if(session()->has('status')): ?>
            <div class="flex justify-center items-center">
                <p class="ml-3 text-sm font-bold text-green-600"><?php echo e(session()->get('status')); ?></p>
            </div>
        <?php endif; ?>
		<div class="posts-head">
            <a class="btn" href="<?php echo e(route('posts.create')); ?>"><?php echo e(__('+ Добавить пост')); ?></a>
            <div class="posts-filters">
                    <button class="home-sort" sort="desc">
                        <div class="home-sort__icon">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="home-sort__text">Сортировка</div>
                    </button>
            </div>
		</div>
		<div class="post-grid _ajax">

         </div>
        </div>
        <div class="pagination"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sergejabramov/Desktop/domains/geek/resources/views/posts/home.blade.php ENDPATH**/ ?>