<button  class="btn" <?php echo e($attributes->merge(['type' => 'submit'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /Users/sergejabramov/Desktop/domains/geek/resources/views/components/primary-button.blade.php ENDPATH**/ ?>