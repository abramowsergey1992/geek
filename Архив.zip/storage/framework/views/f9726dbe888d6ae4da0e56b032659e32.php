 
  <?php $__env->startSection('head'); ?>
<title>Студенты | ActQA</title>
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('content'); ?>
<h1>Студенты</h1>
    <div class="">

	
                    <?php if(session()->has('status')): ?>

                        <div class="flex justify-center items-center">
                            <p class="ml-3 text-sm font-bold text-green-600"><?php echo e(session()->get('status')); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="mt-1 mb-4">
                        <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <a href="<?php echo e(route('students.create')); ?>"><?php echo e(__('+ Добавить студента')); ?></a>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                    </div>
                    <div class="table-overfolow">
                        <table class="table-list">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Имя</th>
                                    <th>Телефон</th>
                                    <th>Роль</th>
                                    
                                <th>Обновленно</th>
                                <th>Дата создания</th>
                                    <th>
                                        
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="user-row">
                                    <td><?php echo e($user->id); ?></td>
									<td>
                                        <a  class="user-row__link" href="<?php echo e(route('students.show', $user->id)); ?>">
											<img src="<?php echo e(asset('storage/images/'.$user->avatar)); ?>" alt="">
											<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

										</a>
									</td>
                                  
                                    <td><?php echo e($user->phone); ?></td>
                                    <td><?php echo e($user->role); ?></td>
                                    <td><?php echo e($user->upodate_at); ?></td>
                                    <td><?php echo e($user->created_at); ?></td>
                                    <td >
										<div class="actions-btns-row">
											<!--  -->
											<a  class="btn-student-edit btn-edit" href="<?php echo e(route('students.edit', $user->id)); ?>">
												<svg  viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m18 10-4-4m4 4 3-3-4-4-3 3m4 4-1 1m-3-5-6 6v4h4l2.5-2.5m5.5.5v6h-8M10 4H4v16h3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
											</a>
								
											<form action="<?php echo e(route('students.destroy', $user->id)); ?>" method="POST"
												onsubmit="return confirm('<?php echo e(trans('are You Sure ? ')); ?>');"
												style="display: inline-block;">
												<input type="hidden" name="_method" value="DELETE">
												<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
												<button type="submit" class="btn-delete"
													value="Delete">
													<svg   viewBox="0 -0.5 21 21" xmlns="http://www.w3.org/2000/svg"><path d="M7.35 16h2.1V8h-2.1v8Zm4.2 0h2.1V8h-2.1v8Zm-6.3 2h10.5V6H5.25v12Zm2.1-14h6.3V2h-6.3v2Zm8.4 0V0H5.25v4H0v2h3.15v14h14.7V6H21V4h-5.25Z" fill="currentColor" fill-rule="evenodd"/></svg>
												</button>
											</form>
										</div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<td colspan="7"  ><b>No Users</b></>
								<?php endif; ?>
                            </tbody>
                        </table>
                 </div>
                 
   
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sergejabramov/Desktop/domains/geek/resources/views/students/index.blade.php ENDPATH**/ ?>