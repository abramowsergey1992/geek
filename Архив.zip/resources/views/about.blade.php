@extends('layouts.layout')

   @section('head')
<title>О нас | ActQA</title>
@endsection 

@section('content')

    <div class="page-about"><h1>О нас</h1>
<p>Мы команда Актион, поставляем профессиональную информацию и знания миллионам специалистов — бухгалтерам, кадровикам, финансистам, юристам, медикам, учителям и управленцам. Кроме этого мы успешно обучаем новым профессиям, подробнее про нас <a href="https://action.group/about/">https://action.group/about/</a></p>
    </div>
@endsection